import os.path
import time
import json
import tweepy
from tweepy import OAuthHandler

lastTweetID = -1
collectFilePath = 'C:\\twitter\\collect.json'

def collecting():
    consumerKey = 'rj6rashVwvj1K6nK0Irv5LCeD'
    consumerSecret = '70AQ4AMzzZdhH8e1YrohT4ZJRqlRhD9c079T00WSeZ3bQRy5XV'
    
    accessToken = '800391268094197760-UM4X7VVxlEh076OU1qj3QDV0mKxJ02w'
    accessSecret = 'wbQgF7M8l5RFsEfIowFx2Q5n7mMfGfLnk24BpzKJwjFe7'
    
    maxRpp = 50
    
    query = 'acidente lang:pt from:PRF191MG since:2011-11-01 until:2016-11-30'

    global lastTweetID
    global collectFilePath
    
    auth = OAuthHandler(consumerKey, consumerSecret)
    auth.set_access_token(accessToken, accessSecret)
    
    api = tweepy.API(auth)
    
    stringDataCollect = '['
    
    if (lastTweetID == -1):
        for tweet in tweepy.Cursor(api.search, q=query, rpp=maxRpp).items():
            stringDataCollect = stringDataCollect + '{"created_at": "' + tweet.created_at.strftime("%Y-%m-%d %a %H:%M") + '", "text": "' + tweet.text + '"}'
            stringDataCollect = stringDataCollect + ', '
            lastTweetID = tweet.id
    else:
        for tweet in tweepy.Cursor(api.search, q=query, rpp=maxRpp, since_id=lastTweetID).items():
            stringDataCollect = stringDataCollect + '{"created_at": "' + tweet.created_at.strftime("%Y-%m-%d %a %H:%M") + '", "text": "' + tweet.text + '"}'
            stringDataCollect = stringDataCollect + ', '
            lastTweetID = tweet.id

    stringDataCollect = stringDataCollect + ']'
    stringDataCollect = stringDataCollect.replace(", ]", "]")

    if os.path.exists(collectFilePath):
        os.remove(collectFilePath)
    
    if (len(stringDataCollect) > 2):
        collectFile = open(collectFilePath, 'a')
        collectFile.write(stringDataCollect)
        collectFile.close()
        mining()

def weekDay(argument):
    switcher = { 'Sun': 'Dom'
               , 'Mon': 'Seg'
               , 'Tue': 'Ter'
               , 'Wed': 'Qua'
               , 'Thu': 'Qui'
               , 'Fri': 'Sex'
               , 'Sat': 'Sáb' }
    return switcher.get(argument, 'Not')

def numberWeekDay(argument):
    switcher = { 'Sun': 1
               , 'Mon': 2
               , 'Tue': 3
               , 'Wed': 4
               , 'Thu': 5
               , 'Fri': 6
               , 'Sat': 7 }
    return switcher.get(argument, 0)

def textMonth(argument):
    switcher = { '01': 'Jan'
               , '02': 'Fev'
               , '03': 'Mar'
               , '04': 'Abr'
               , '05': 'Mai'
               , '06': 'Jun'
               , '07': 'Jul'
               , '08': 'Ago'
               , '09': 'Set'
               , '10': 'Out'
               , '11': 'Nov'
               , '12': 'Dez' }
    return switcher.get(argument, 'Not')

def mining():
    miningFilePath = 'C:\\twitter\\mining\\'
    miningFileName = 'mining_' + time.strftime('%Y%m%d') + '_' + time.strftime('%H%M%S') + '.json'
    
    highways = [ 'BR040'
               , 'BR050'
               , 'BR116'
               , 'BR135'
               , 'BR153'
               , 'BR262'
               , 'BR265'
               , 'BR267'
               , 'BR365'
               , 'BR381'
               , 'BR459'
               , 'MG010'
               , 'MG020'
               , 'MG030'
               , 'MG040'
               , 'MG050'
               , 'MG060'
               , 'MG105'
               , 'MG108'
               , 'MG111'
               , 'MG114'
               , 'MG117'
               , 'MG120'
               , 'MG123'
               , 'MG124'
               , 'MG126'
               , 'MG129'
               , 'MG132'
               , 'MG133'
               , 'MG135'
               , 'MG155'
               , 'MG158'
               , 'MG161'
               , 'MG164'
               , 'MG167'
               , 'MG170'
               , 'MG173'
               , 'MG176'
               , 'MG179'
               , 'MG181'
               , 'MG184'
               , 'MG187'
               , 'MG188'
               , 'MG190'
               , 'MG202'
               , 'MG205'
               , 'MG208'
               , 'MG211'
               , 'MG214'
               , 'MG217'
               , 'MG220'
               , 'MG223'
               , 'MG226'
               , 'MG229'
               , 'MG230'
               , 'MG231'
               , 'MG232'
               , 'MG235'
               , 'MG238'
               , 'MG252'
               , 'MG255'
               , 'MG260'
               , 'MG262'
               , 'MG265'
               , 'MG270'
               , 'MG275'
               , 'MG280'
               , 'MG285'
               , 'MG290'
               , 'MG295'
               , 'MG305'
               , 'MG307'
               , 'MG308'
               , 'MG311'
               , 'MG314'
               , 'MG317'
               , 'MG320'
               , 'MG323'
               , 'MG326'
               , 'MG329'
               , 'MG332'
               , 'MG335'
               , 'MG338'
               , 'MG341'
               , 'MG344'
               , 'MG347'
               , 'MG350'
               , 'MG353'
               , 'MG400'
               , 'MG401'
               , 'MG402'
               , 'MG403'
               , 'MG404'
               , 'MG405'
               , 'MG406'
               , 'MG407'
               , 'MG408'
               , 'MG409'
               , 'MG410'
               , 'MG411'
               , 'MG412'
               , 'MG413'
               , 'MG414'
               , 'MG415'
               , 'MG416'
               , 'MG417'
               , 'MG418'
               , 'MG419'
               , 'MG420'
               , 'MG421'
               , 'MG422'
               , 'MG423'
               , 'MG424'
               , 'MG425'
               , 'MG426'
               , 'MG427'
               , 'MG428'
               , 'MG429'
               , 'MG430'
               , 'MG431'
               , 'MG432'
               , 'MG433'
               , 'MG434'
               , 'MG435'
               , 'MG436'
               , 'MG437'
               , 'MG438'
               , 'MG439'
               , 'MG440'
               , 'MG441'
               , 'MG442'
               , 'MG443'
               , 'MG444'
               , 'MG445'
               , 'MG446'
               , 'MG447'
               , 'MG448'
               , 'MG449'
               , 'MG450'
               , 'MG451'
               , 'MG452'
               , 'MG453'
               , 'MG454'
               , 'MG455'
               , 'MG456'
               , 'MG457'
               , 'MG458'
               , 'MG459'
               , 'MG460'
               , 'MG461' ]

    if os.path.exists(collectFilePath):
        collectedFile = open(collectFilePath, 'r')
        jsonCollectedFile = json.load(collectedFile)

        stringDataMining = '['

        for jsonCollectedItem in jsonCollectedFile:
            for highway in highways:
                tweetText = jsonCollectedItem['text'].replace(" ", "")
                tweetText = tweetText.replace("-", "")

                if (tweetText.find(highway) > 0):
                    stringDataMining = stringDataMining + '{"year": "' + str(jsonCollectedItem['created_at'][0:4]) + '", "month": "' + str(jsonCollectedItem['created_at'][5:7]) + '", "textmonth": "' + textMonth(str(jsonCollectedItem['created_at'][5:7])) + '", "day": "' + str(jsonCollectedItem['created_at'][8:10]) + '", "weekday": "' + weekDay(str(jsonCollectedItem['created_at'][11:14])) + '", "numberweekday": "' + str(numberWeekDay(str(jsonCollectedItem['created_at'][11:14]))) + '", "tweettime": "' + str(jsonCollectedItem['created_at'][15:20]) + '", "tweet": "' + str(jsonCollectedItem['text']) + '", "highwaytype": "' + str(highway[0:2]) + '", "highway": "' + str(highway) + '"}'
                    stringDataMining = stringDataMining + ', '

        stringDataMining = stringDataMining + ']'
        stringDataMining = stringDataMining.replace(", ]", "]")

        if os.path.exists(miningFilePath + miningFileName):
            os.remove(miningFilePath + miningFileName)

        miningFile = open(miningFilePath + miningFileName, 'a')
        miningFile.write(stringDataMining)

        miningFile.close()
        collectedFile.close()
        os.remove(collectFilePath)

if __name__ == '__main__':
    while True:
        try:
            collecting()
        except tweepy.RateLimitError:
            time.sleep(20 * 60)

