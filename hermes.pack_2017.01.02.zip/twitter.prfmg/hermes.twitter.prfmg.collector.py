import traceback
import os.path
import time
import json
import tweepy

collectFilePath = 'C:\\datalake\\twitter.prfmg\\hermes.twitter.prfmg.collect.json'

def weekDay(argument):
    switcher = { 'Sun': 'Dom'
               , 'Mon': 'Seg'
               , 'Tue': 'Ter'
               , 'Wed': 'Qua'
               , 'Thu': 'Qui'
               , 'Fri': 'Sex'
               , 'Sat': 'Sáb' }
    return switcher.get(argument, 'Not')

def numberWeekDay(argument):
    switcher = { 'Sun': 1
               , 'Mon': 2
               , 'Tue': 3
               , 'Wed': 4
               , 'Thu': 5
               , 'Fri': 6
               , 'Sat': 7 }
    return switcher.get(argument, 0)

def textMonth(argument):
    switcher = { '01': 'Jan'
               , '02': 'Fev'
               , '03': 'Mar'
               , '04': 'Abr'
               , '05': 'Mai'
               , '06': 'Jun'
               , '07': 'Jul'
               , '08': 'Ago'
               , '09': 'Set'
               , '10': 'Out'
               , '11': 'Nov'
               , '12': 'Dez' }
    return switcher.get(argument, 'Not')

def mining():
    global collectFilePath

    miningFilePath = 'C:\\datalake\\twitter.prfmg\\data\\mining\\'
    miningFileName = 'hermes.twitter.prfmg.mining' + time.strftime('.%Y%m%d.') + time.strftime('%H%M%S') + '.json'

    highways = [ 'BR040'
               , 'BR050'
               , 'BR116'
               , 'BR135'
               , 'BR153'
               , 'BR262'
               , 'BR265'
               , 'BR267'
               , 'BR365'
               , 'BR381'
               , 'BR459'
               , 'MG010'
               , 'MG020'
               , 'MG030'
               , 'MG040'
               , 'MG050'
               , 'MG060'
               , 'MG105'
               , 'MG108'
               , 'MG111'
               , 'MG114'
               , 'MG117'
               , 'MG120'
               , 'MG123'
               , 'MG124'
               , 'MG126'
               , 'MG129'
               , 'MG132'
               , 'MG133'
               , 'MG135'
               , 'MG155'
               , 'MG158'
               , 'MG161'
               , 'MG164'
               , 'MG167'
               , 'MG170'
               , 'MG173'
               , 'MG176'
               , 'MG179'
               , 'MG181'
               , 'MG184'
               , 'MG187'
               , 'MG188'
               , 'MG190'
               , 'MG202'
               , 'MG205'
               , 'MG208'
               , 'MG211'
               , 'MG214'
               , 'MG217'
               , 'MG220'
               , 'MG223'
               , 'MG226'
               , 'MG229'
               , 'MG230'
               , 'MG231'
               , 'MG232'
               , 'MG235'
               , 'MG238'
               , 'MG252'
               , 'MG255'
               , 'MG260'
               , 'MG262'
               , 'MG265'
               , 'MG270'
               , 'MG275'
               , 'MG280'
               , 'MG285'
               , 'MG290'
               , 'MG295'
               , 'MG305'
               , 'MG307'
               , 'MG308'
               , 'MG311'
               , 'MG314'
               , 'MG317'
               , 'MG320'
               , 'MG323'
               , 'MG326'
               , 'MG329'
               , 'MG332'
               , 'MG335'
               , 'MG338'
               , 'MG341'
               , 'MG344'
               , 'MG347'
               , 'MG350'
               , 'MG353'
               , 'MG400'
               , 'MG401'
               , 'MG402'
               , 'MG403'
               , 'MG404'
               , 'MG405'
               , 'MG406'
               , 'MG407'
               , 'MG408'
               , 'MG409'
               , 'MG410'
               , 'MG411'
               , 'MG412'
               , 'MG413'
               , 'MG414'
               , 'MG415'
               , 'MG416'
               , 'MG417'
               , 'MG418'
               , 'MG419'
               , 'MG420'
               , 'MG421'
               , 'MG422'
               , 'MG423'
               , 'MG424'
               , 'MG425'
               , 'MG426'
               , 'MG427'
               , 'MG428'
               , 'MG429'
               , 'MG430'
               , 'MG431'
               , 'MG432'
               , 'MG433'
               , 'MG434'
               , 'MG435'
               , 'MG436'
               , 'MG437'
               , 'MG438'
               , 'MG439'
               , 'MG440'
               , 'MG441'
               , 'MG442'
               , 'MG443'
               , 'MG444'
               , 'MG445'
               , 'MG446'
               , 'MG447'
               , 'MG448'
               , 'MG449'
               , 'MG450'
               , 'MG451'
               , 'MG452'
               , 'MG453'
               , 'MG454'
               , 'MG455'
               , 'MG456'
               , 'MG457'
               , 'MG458'
               , 'MG459'
               , 'MG460'
               , 'MG461' ]

    if os.path.exists(collectFilePath):
        collectedFile = open(collectFilePath, 'r')
        jsonCollectedFile = json.load(collectedFile)

        stringDataMining = '['

        for jsonCollectedItem in jsonCollectedFile:
            for highway in highways:
                tweetText = jsonCollectedItem['text'].replace(' ', '')
                tweetText = tweetText.replace('-', '')
                tweetText = tweetText.upper()

                if ((tweetText.find('ACIDENTE') >= 0) and (tweetText.find(highway) >= 0)):
                    stringDataMining = stringDataMining + '{"year": "' + str(jsonCollectedItem['created_at'][0:4]) + '", "month": "' + str(jsonCollectedItem['created_at'][5:7]) + '", "textmonth": "' + textMonth(str(jsonCollectedItem['created_at'][5:7])) + '", "day": "' + str(jsonCollectedItem['created_at'][8:10]) + '", "weekday": "' + weekDay(str(jsonCollectedItem['created_at'][11:14])) + '", "numberweekday": "' + str(numberWeekDay(str(jsonCollectedItem['created_at'][11:14]))) + '", "tweettime": "' + str(jsonCollectedItem['created_at'][15:20]) + '", "tweet": "' + str(jsonCollectedItem['text']) + '", "highwaytype": "' + str(highway[0:2]) + '", "highway": "' + str(highway) + '"}'
                    stringDataMining = stringDataMining + ', '

        stringDataMining = stringDataMining + ']'
        stringDataMining = stringDataMining.replace(", ]", "]")

        if os.path.exists(miningFilePath + miningFileName):
            os.remove(miningFilePath)

        miningFile = open(miningFilePath + miningFileName, 'a')
        miningFile.write(stringDataMining)

        miningFile.close()
        collectedFile.close()

def getTweetID(typeID):
    global collectFilePath

    if os.path.exists(collectFilePath):
        file = open(collectFilePath, 'r')
        jsonFile = json.load(file)

        for jsonItem in jsonFile:
            returnID = int(jsonItem['id'])

            if (typeID == 'max'):
                returnID = (returnID + 1)
                break

        if (typeID == 'min'):
            returnID = (returnID - 1)

        file.close()
    else:
        returnID = -1

    return str(returnID)

def collecting(tweets):
    global collectFilePath

    stringDataCollect = '['

    for tweet in tweets:
        tweetText = tweet.text.replace(' ', '')
        tweetText = tweetText.upper()

        if ((tweet.retweeted == False) and (tweetText.find('RT@') < 0) and (tweetText.find('RETWEETED') < 0)):
            stringDataCollect = stringDataCollect + '{"id": "' + str(tweet.id) + '", "created_at": "' + tweet.created_at.strftime("%Y-%m-%d %a %H:%M") + '", "text": "' + tweet.text.replace('"', '') + '"}'
            stringDataCollect = stringDataCollect + ', '

    stringDataCollect = stringDataCollect + ']'
    stringDataCollect = stringDataCollect.replace(", ]", "]")

    if (len(stringDataCollect) > 2):
        if os.path.exists(collectFilePath):
            os.remove(collectFilePath)

        collectFile = open(collectFilePath, 'a')
        collectFile.write(stringDataCollect)
        collectFile.close()

if __name__ == '__main__':
    consumerKey = 'vexib6OG4OCXgFeeiTqRxjaTd'
    consumerSecret = 'hnuB1eb4SgjImz7Ui4GwvmD2cpsImC1JjnI3myWAhn30Ofc606'
    
    accessToken = '800391268094197760-pbt44zdUTGF94MjvK04j4YpszXm0Xl3'
    accessSecret = 'sfZIvUBMMSs6xKz8tzVpYT6OeA48ySl6cOpqJcwMg83hL'

    auth = tweepy.OAuthHandler(consumerKey, consumerSecret)
    auth.set_access_token(accessToken, accessSecret)
    api = tweepy.API(auth, wait_on_rate_limit = True)

    maxCount = '100'
    query = 'PRF MINAS GERAIS'

    while True:
        try:
            maxTweetID = getTweetID('min')
        
            if (maxTweetID == '-1'):
                result = api.search(q=query, count=maxCount)
            else:
                result = api.search(q=query, count=maxCount, max_id=maxTweetID)

            collecting(result)
        except Exception as e:
            print('Erro: ')
            print(e)
            print(' ')
            print(' ')
            print('Tracer: ')
            traceback.print_exc()
            print(' ')
            print(' ')
            time.sleep(3)
            continue
